import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Shield, Clock, CheckCircle, User as UserIcon, ArrowLeft, XCircle } from "lucide-react";

import { getDeviceId } from "@/hooks/use-emergency";

export default function Profile() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [userName, setUserName] = useState<string>("");
  const [deviceId, setDeviceId] = useState<string>("");

  useEffect(() => {
    const storedName = localStorage.getItem("userName") || "Anonymous";
    const id = getDeviceId();
    setUserName(storedName);
    setDeviceId(id);
  }, []);

  const { data: resQuest = [], isLoading: loadingQuest } = useQuery<any[]>({
    queryKey: ["/api/history/resquest", deviceId],
    enabled: !!deviceId,
  });

  const { data: resQued = [], isLoading: loadingQued } = useQuery<any[]>({
    queryKey: ["/api/history/resqued", deviceId],
    enabled: !!deviceId,
  });

  const verifyMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("POST", `/api/alerts/${id}/verify`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/history/resquest", deviceId] });
      toast({ title: "Help Verified!", description: "Thank you for confirming." });
    }
  });

  const cancelMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/alerts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/history/resquest", deviceId] });
      toast({ title: "Request Cancelled", description: "Your SOS request has been removed." });
    }
  });

  const handleNameSave = () => {
    localStorage.setItem("userName", userName);
    toast({ title: "Profile Updated", description: "Your display name has been saved." });
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="max-w-4xl mx-auto mb-8 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation("/")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center space-x-3">
            <div className="bg-red-600 p-2 rounded-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold font-display">ResQ Profile</h1>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Profile Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Display Name</Label>
              <div className="flex gap-2">
                <Input 
                  id="name" 
                  value={userName} 
                  onChange={(e) => setUserName(e.target.value)} 
                  placeholder="Enter your name"
                />
                <Button onClick={handleNameSave}>Save</Button>
              </div>
              <p className="text-xs text-gray-500">This name will be shown to others when you request or provide help.</p>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <h2 className="text-xl font-semibold">My Requests</h2>
          <div className="space-y-4">
            {loadingQuest ? (
              <p className="text-center py-8">Loading history...</p>
            ) : resQuest.length === 0 ? (
              <p className="text-center py-8 text-gray-500">No requests made yet.</p>
            ) : (
              resQuest.map((alert: any) => (
                <Card key={alert.id}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Level {alert.level} SOS
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-gray-500">
                        {new Date(alert.createdAt).toLocaleDateString()}
                      </span>
                      {alert.active && !alert.helperId && (
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-6 w-6 text-red-500 hover:text-red-700 hover:bg-red-50"
                          onClick={() => cancelMutation.mutate(alert.id)}
                          disabled={cancelMutation.isPending}
                        >
                          <XCircle className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-4">{alert.message}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {alert.helperId ? (
                          <div className="flex flex-col gap-1">
                            <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full flex items-center w-fit">
                              <CheckCircle className="w-3 h-3 mr-1" /> Helped by {alert.helperName || "someone"}
                            </span>
                          </div>
                        ) : alert.active ? (
                          <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> Pending
                          </span>
                        ) : (
                          <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded-full flex items-center">
                            <XCircle className="w-3 h-3 mr-1" /> Closed
                          </span>
                        )}
                        {alert.isResqued && (
                          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Verified</span>
                        )}
                      </div>
                      {alert.helperId && !alert.isResqued && (
                        <Button size="sm" onClick={() => verifyMutation.mutate(alert.id)}>
                          Verify Help
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}