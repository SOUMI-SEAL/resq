import { pgTable, text, real, integer, boolean, timestamp, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull().unique(), // stored in localStorage
  email: text("email").unique(),
  password: text("password"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  lastSeen: timestamp("last_seen").defaultNow(),
  name: text("name"), // Optional name
});

export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(), // Who sent it
  name: text("name"), // Display name of requester
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  level: integer("level").default(1).notNull(), // 1: Immediate, 2: Urgent, 3: Semi-urgent
  message: text("message").notNull(),
  active: boolean("active").default(true),
  helperId: text("helper_id"), // Device ID of helper
  helperName: text("helper_name"), // Display name of helper
  isResqued: boolean("is_resqued").default(false), // Help verified by requester
  createdAt: timestamp("created_at").defaultNow(),
});

// === SCHEMAS ===
export const insertUserSchema = createInsertSchema(users).pick({
  deviceId: true,
  latitude: true,
  longitude: true,
  name: true,
});

export const insertAlertSchema = createInsertSchema(alerts).pick({
  deviceId: true,
  name: true,
  latitude: true,
  longitude: true,
  level: true,
  message: true,
});

// === TYPES ===
export type User = typeof users.$inferSelect;
export type Alert = typeof alerts.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
